## examples/SecurityRules/Releases

* [SecurityRules](/examples/SecurityRules/)
    * [Releases](/examples/SecurityRules/Releases/)
        * [Create](/examples/SecurityRules/Releases/Create)
        * [Delete](/examples/SecurityRules/Releases/Delete)
        * [Get](/examples/SecurityRules/Releases/Get)
        * [GetExecutable](/examples/SecurityRules/Releases/GetExecutable)
        * [List](/examples/SecurityRules/Releases/List)
        * [Patch](/examples/SecurityRules/Releases/Patch)