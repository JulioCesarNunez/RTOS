## examples/FirestoreDatabase/CollectionGroups/Indexes

* [FirestoreDatabase](/examples/FirestoreDatabase/)
    * [CollectionGroups](/examples/FirestoreDatabase//CollectionGroups/)
        * [Indexes](/examples/FirestoreDatabase/CollectionGroups/Indexes/)
            * [Create](/examples/FirestoreDatabase/CollectionGroups/Indexes/Create/)
            * [Delete](/examples/FirestoreDatabase/CollectionGroups/Indexes/Delete/)
            * [Get](/examples/FirestoreDatabase/CollectionGroups/Indexes/Get/)
            * [List](/examples/FirestoreDatabase/CollectionGroups/Indexes/List/)