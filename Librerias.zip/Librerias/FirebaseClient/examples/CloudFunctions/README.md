## examples/CloudFunctions

* [CloudFunctions](/examples/CloudFunctions/)
    * [Call](/examples/CloudFunctions/Call/)
    * [Create](/examples/CloudFunctions/Create/)
    * [Delete](/examples/CloudFunctions/Delete/)
    * [GenDownloadURL](/examples/CloudFunctions/GenDownloadURL/)
    * [GenUploadURL](/examples/CloudFunctions/GenUploadURL/)
    * [Get](/examples/CloudFunctions/Get/)
    * [GetIamPolicy](/examples/CloudFunctions/GetIamPolicy/)
    * [List](/examples/CloudFunctions/List/)
    * [Patch](/examples/CloudFunctions/Patch/)
    * [SetIamPolicy](/examples/CloudFunctions/SetIamPolicy/)
    * [TestIamPermissions](/examples/CloudFunctions/TestIamPermissions/)